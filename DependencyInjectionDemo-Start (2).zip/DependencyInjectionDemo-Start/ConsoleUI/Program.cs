﻿using Dodatek;
using System;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 class1 = new Class1();
            class1.Test();


            Console.ReadLine();
        }
    }
}
