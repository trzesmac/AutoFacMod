﻿using DemoLibrary.Utilities;
using System;

namespace DemoLibrary
{
    public class BetterBusinessLogic : IBusinessLogic
    {
        private readonly ILogger _logger;
        private readonly IDataAccess _dataAccess;

        public BetterBusinessLogic(ILogger logger, IDataAccess dataAccess)
        {
            _logger = logger;
            _dataAccess = dataAccess;
        }

        public void ProcessData()
        {
            _logger.Log("Starting the better processing of data.");
            Console.WriteLine();
            Console.WriteLine("Better processing the data");
            _dataAccess.LoadData();
            _dataAccess.SaveData("ProcessedInfo");
            Console.WriteLine();
            _logger.Log("Finished better processing of the data.");
            Console.WriteLine();
        }
    }
}
