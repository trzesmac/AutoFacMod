﻿namespace DemoLibrary
{
    public interface IApplication
    {
        void Run();
    }
}