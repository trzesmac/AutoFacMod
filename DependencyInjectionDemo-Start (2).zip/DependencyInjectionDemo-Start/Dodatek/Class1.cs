﻿using AutoFacHelper;
using DemoLibrary;
using DemoLibrary.Utilities;

namespace Dodatek
{
    public class Class1
    {
        private readonly ILogger _logger;
        private readonly IApplication _application;
        public Class1()
        {
            _logger = ScopeStarter.LoggerScopeStart();
            _application = ScopeStarter.ApplicationScopeStart();
        }

        public void Test()
        {
            _logger.Log("Class1 Test");
            _application.Run();
        }
    }
}
